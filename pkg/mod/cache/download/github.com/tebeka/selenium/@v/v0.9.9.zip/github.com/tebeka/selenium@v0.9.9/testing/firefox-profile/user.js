user_pref("browser.startup.homepage", "about:config");
user_pref("browser.startup.page", "1");
