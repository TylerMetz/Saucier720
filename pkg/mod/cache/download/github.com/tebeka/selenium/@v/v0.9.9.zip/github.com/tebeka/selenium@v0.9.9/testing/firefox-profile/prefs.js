user_pref("browser.startup.homepage_override.mstone", "ignore");
